# Predictive Resource Allocation — Flood-Relief Demand Forecasting (Coastal Odisha)

## 1. Use case
Forecast weekly demand for relief resources (dry rations, drinking water, ORS, tarpaulin,
medical kits) for coastal Odisha districts (Puri, Ganjam, Kendrapara, Balasore, Bhadrak,
Jagatsinghpur) for the next 7–30 days, using rainfall, river-gauge, population, road-access
and past-incident data.

## 2. Folder structure
```
odisha_flood_project/
├── data/
│   ├── raw/          <- raw downloaded files go here (one subfolder per source)
│   ├── processed/    <- cleaned, district-week granular CSVs
│   └── geo/           <- shapefiles / GeoJSON for district boundaries
├── scripts/
│   ├── 01_fetch_rainfall.py
│   ├── 02_fetch_river_gauge.py
│   ├── 03_fetch_incidents.py
│   ├── 04_fetch_population_geo.py
│   ├── 05_fetch_roads_osm.py
│   ├── 06_feature_engineering.py   <- lags, wavelet, HAR features
│   └── 07_build_master_csv.py      <- merges everything -> master_csv.csv
├── notebooks/
│   └── modeling.ipynb   (SARIMA, HAR, wavelet+LightGBM/LSTM, evaluation)
└── dashboard/
    └── app.py (Streamlit + GeoPandas/Folium)
```

## 3. Data sources & how to get them

| # | Data | Source | Access method | Notes |
|---|------|--------|----------------|-------|
| 1 | Daily rainfall (district-wise) | IMD via data.gov.in | data.gov.in API / CSV download | search "rainfall district wise Odisha" |
| 2 | River gauge levels | CWC India-WRIS / ffs.india-water.gov.in | manual CSV export or scraping (check ToS) | flood-stage thresholds per gauge site |
| 3 | Disaster incidents + relief dispatch (target) | OSDMA (Odisha SDMA) situation reports, NDMA, ReliefWeb/OCHA | PDF/CSV reports — manual extraction or PDF parsing | this is the hardest, most manual part |
| 4 | Population & density | Census 2011 (censusindia.gov.in), SEDAC GPWv4 | CSV / raster (.tif), zonal stats with rasterio+geopandas | static, doesn't change yearly |
| 5 | District boundaries (shapefile) | data.gov.in / GADM (gadm.org) / Bhuvan | shapefile / GeoJSON download | use to clip & spatially join everything |
| 6 | Road network density | OpenStreetMap via OSMnx | `osmnx` python package, no manual download | computes km of road per district area |
| 7 | IMD rainfall forecast (stretch) | IMD API (mausam.imd.gov.in) | API key needed | forward-looking signal |

## 4. Pipeline order
1. Run `01`–`05` to populate `data/raw/` and `data/geo/`.
2. Run `06_feature_engineering.py` — produces wavelet decomposition columns, HAR lag
   aggregates (daily/weekly/monthly rainfall+gauge averages), and standard lag features.
3. Run `07_build_master_csv.py` — spatial + temporal join of all processed tables into
   `data/processed/master_csv.csv` at (district, week) granularity. This is the file
   used to train SARIMA / HAR / wavelet-augmented LightGBM/LSTM models.
4. Modeling notebook reads `master_csv.csv`.
5. Dashboard reads model output + `data/geo/odisha_districts.geojson`.

## 5. master_csv schema (target columns)
- `district`, `week_start_date`
- `rainfall_mm_sum`, `rainfall_mm_lag1`, `rainfall_mm_lag4` (HAR daily/weekly/monthly lags)
- `wavelet_rainfall_d1..dN`, `wavelet_rainfall_approx` (wavelet coefficients)
- `river_gauge_level`, `gauge_above_flood_stage` (0/1)
- `population`, `population_density`
- `road_density_km_per_sqkm`
- `past_incident_count_4wk`, `past_incident_severity_avg`
- `target_kits_demand`, `target_water_liters_demand`, `target_ors_units_demand` (label —
  may need to be constructed via SPHERE per-capita norms if dispatch data unavailable)

## 6. Notes on handling data gaps
- Where district-level rainfall is missing, fall back to gridded IMD rainfall (0.25°x0.25°)
  aggregated via geopandas zonal stats over district polygons.
- For missing incident/dispatch records, construct a synthetic target using:
  `target = affected_population * SPHERE_per_capita_norm * severity_factor`
- Flag all imputed/synthetic rows with a `is_synthetic_target` column for transparency.
