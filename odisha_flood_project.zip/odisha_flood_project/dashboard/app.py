"""
app.py - Streamlit dashboard skeleton
---------------------------------------
Run with: streamlit run dashboard/app.py

Shows:
- District map (GeoPandas + Folium) colored by predicted demand
- Time-series chart of forecast vs actual for selected district
- Simple table for NGO ops manager
"""

import pandas as pd
import streamlit as st

try:
    import geopandas as gpd
    import folium
    from streamlit_folium import st_folium
except ImportError:
    gpd = None

MASTER_PATH = "data/processed/master_csv.csv"
GEO_PATH = "data/geo/odisha_districts.geojson"

st.set_page_config(page_title="Flood Relief Demand Dashboard", layout="wide")
st.title("Coastal Odisha — Flood Relief Resource Demand Forecast")

try:
    df = pd.read_csv(MASTER_PATH, parse_dates=["week_start_date"])
except FileNotFoundError:
    st.warning("master_csv.csv not found. Run the data pipeline scripts first.")
    st.stop()

districts = sorted(df["district"].unique())
selected = st.sidebar.selectbox("Select district", districts)

district_df = df[df["district"] == selected].sort_values("week_start_date")

st.subheader(f"{selected}: Weekly resource demand (latest data)")
st.line_chart(district_df.set_index("week_start_date")[
    [c for c in ["target_water_liters_demand", "target_kits_demand",
                  "target_ors_units_demand"] if c in district_df.columns]
])

st.subheader("Latest week snapshot")
st.dataframe(district_df.tail(1).T)

if gpd is not None:
    try:
        gdf = gpd.read_file(GEO_PATH)
        latest = df.sort_values("week_start_date").groupby("district").tail(1)
        gdf = gdf.merge(latest[["district", "target_water_liters_demand"]], on="district", how="left")

        m = folium.Map(location=[19.8, 85.8], zoom_start=7)
        folium.Choropleth(
            geo_data=gdf,
            data=gdf,
            columns=["district", "target_water_liters_demand"],
            key_on="feature.properties.district",
            fill_color="YlOrRd",
            legend_name="Predicted water demand (L)",
        ).add_to(m)
        st.subheader("District-level demand map")
        st_folium(m, width=900, height=500)
    except Exception as e:
        st.info(f"Map unavailable: {e}")
else:
    st.info("Install geopandas, folium, streamlit-folium to enable the map view.")
