"""
modeling_starter.py
---------------------
Starter modeling script (convert to notebook as needed).
Reads data/processed/master_csv.csv and trains:
  1. SARIMA baseline per district on target_water_liters_demand
  2. HAR-style linear regression using HAR lag features
  3. Wavelet-augmented LightGBM (non-linear) using all engineered features

Evaluates each with MAE, RMSE, MAPE on a hold-out tail of each district's series.
"""

import pandas as pd
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.linear_model import LinearRegression

MASTER_PATH = "data/processed/master_csv.csv"
TARGET = "target_water_liters_demand"
TEST_WEEKS = 8  # hold-out horizon


def mape(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    mask = y_true != 0
    if mask.sum() == 0:
        return np.nan
    return np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100


def evaluate(y_true, y_pred, name):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = mean_squared_error(y_true, y_pred, squared=False)
    m = mape(y_true, y_pred)
    print(f"{name}: MAE={mae:.2f}  RMSE={rmse:.2f}  MAPE={m:.2f}%")
    return {"model": name, "MAE": mae, "RMSE": rmse, "MAPE": m}


def run_sarima(series_train, steps):
    from statsmodels.tsa.statespace.sarimax import SARIMAX
    model = SARIMAX(series_train, order=(1, 1, 1), seasonal_order=(1, 1, 1, 52),
                     enforce_stationarity=False, enforce_invertibility=False)
    fit = model.fit(disp=False)
    return fit.forecast(steps=steps)


def run_har(train_df, test_df, feature_cols):
    X_train = train_df[feature_cols].fillna(0)
    y_train = train_df[TARGET]
    X_test = test_df[feature_cols].fillna(0)
    model = LinearRegression().fit(X_train, y_train)
    return model.predict(X_test)


def run_lgbm(train_df, test_df, feature_cols):
    import lightgbm as lgb
    X_train = train_df[feature_cols].fillna(0)
    y_train = train_df[TARGET]
    X_test = test_df[feature_cols].fillna(0)
    model = lgb.LGBMRegressor(n_estimators=300, learning_rate=0.05)
    model.fit(X_train, y_train)
    return model.predict(X_test)


def main():
    df = pd.read_csv(MASTER_PATH, parse_dates=["week_start_date"])
    if df.empty or TARGET not in df.columns:
        print("master_csv.csv is empty or missing target column. Populate data first.")
        return

    har_cols = ["rainfall_har_daily", "rainfall_har_weekly", "rainfall_har_monthly"]
    wavelet_cols = ["wavelet_approx", "wavelet_detail_1", "wavelet_detail_2", "wavelet_detail_3"]
    other_cols = ["rainfall_lag1", "rainfall_lag2", "rainfall_lag4",
                   "gauge_level_mean", "gauge_above_flood_stage_any",
                   "population_density", "road_density_km_per_sqkm",
                   "past_incident_count_4wk"]
    all_feature_cols = [c for c in har_cols + wavelet_cols + other_cols if c in df.columns]

    results = []
    for district, g in df.groupby("district"):
        g = g.sort_values("week_start_date").dropna(subset=[TARGET])
        if len(g) < TEST_WEEKS + 12:
            print(f"Skipping {district}: not enough data ({len(g)} rows)")
            continue

        train, test = g.iloc[:-TEST_WEEKS], g.iloc[-TEST_WEEKS:]

        # SARIMA
        try:
            sarima_pred = run_sarima(train[TARGET], TEST_WEEKS)
            results.append(evaluate(test[TARGET], sarima_pred, f"{district}-SARIMA"))
        except Exception as e:
            print(f"SARIMA failed for {district}: {e}")

        # HAR
        try:
            har_pred = run_har(train, test, har_cols)
            results.append(evaluate(test[TARGET], har_pred, f"{district}-HAR"))
        except Exception as e:
            print(f"HAR failed for {district}: {e}")

        # Wavelet + LightGBM
        try:
            lgbm_pred = run_lgbm(train, test, all_feature_cols)
            results.append(evaluate(test[TARGET], lgbm_pred, f"{district}-Wavelet+LGBM"))
        except Exception as e:
            print(f"LightGBM failed for {district}: {e}")

    pd.DataFrame(results).to_csv("data/processed/model_evaluation.csv", index=False)
    print("Saved evaluation results to data/processed/model_evaluation.csv")


if __name__ == "__main__":
    main()
