"""
01_fetch_rainfall.py
---------------------
Fetch / load district-wise daily rainfall data for Odisha coastal districts.

Two modes:
1. API mode: pulls from data.gov.in IMD rainfall resource (requires API key).
2. Manual mode: if you've downloaded a CSV from data.gov.in / IMD into
   data/raw/rainfall/ manually, this script just standardizes its format.

Output: data/processed/rainfall_daily.csv
Columns: date, district, rainfall_mm
"""

import os
import pandas as pd
import requests

RAW_DIR = "data/raw/rainfall"
OUT_PATH = "data/processed/rainfall_daily.csv"
DISTRICTS = ["Puri", "Ganjam", "Kendrapara", "Balasore", "Bhadrak", "Jagatsinghpur"]

# --- Option A: data.gov.in API ---
DATA_GOV_API_KEY = os.environ.get("DATA_GOV_API_KEY", "")
# Example resource id - search data.gov.in for "Rainfall data" and replace this id
RESOURCE_ID = "REPLACE_WITH_RESOURCE_ID"
API_URL = f"https://api.data.gov.in/resource/{RESOURCE_ID}"


def fetch_from_api(limit=1000):
    if not DATA_GOV_API_KEY or RESOURCE_ID.startswith("REPLACE"):
        print("API key / resource id not set — skipping API fetch.")
        return None
    records = []
    offset = 0
    while True:
        params = {
            "api-key": DATA_GOV_API_KEY,
            "format": "json",
            "limit": limit,
            "offset": offset,
        }
        r = requests.get(API_URL, params=params, timeout=60)
        r.raise_for_status()
        data = r.json().get("records", [])
        if not data:
            break
        records.extend(data)
        offset += limit
    return pd.DataFrame(records)


def load_manual_csvs():
    """Load any CSVs the user manually placed in data/raw/rainfall/"""
    frames = []
    if not os.path.isdir(RAW_DIR):
        return None
    for fname in os.listdir(RAW_DIR):
        if fname.lower().endswith(".csv"):
            df = pd.read_csv(os.path.join(RAW_DIR, fname))
            frames.append(df)
    if not frames:
        return None
    return pd.concat(frames, ignore_index=True)


def standardize(df):
    """
    Map whatever columns exist to: date, district, rainfall_mm
    Edit the column-name mapping below to match your actual downloaded file.
    """
    col_map = {
        "DATE": "date",
        "Date": "date",
        "DISTRICT": "district",
        "District": "district",
        "ACTUAL_RAINFALL": "rainfall_mm",
        "Rainfall": "rainfall_mm",
    }
    df = df.rename(columns=col_map)
    df = df[["date", "district", "rainfall_mm"]]
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df["district"] = df["district"].str.strip().str.title()
    df = df[df["district"].isin(DISTRICTS)]
    df["rainfall_mm"] = pd.to_numeric(df["rainfall_mm"], errors="coerce")
    return df.dropna(subset=["date", "district"])


def main():
    os.makedirs("data/processed", exist_ok=True)
    df = fetch_from_api()
    if df is None:
        df = load_manual_csvs()
    if df is None:
        print(f"No rainfall data found. Place CSVs in {RAW_DIR}/ "
              f"or set DATA_GOV_API_KEY + RESOURCE_ID.")
        # write empty template so downstream merge doesn't break
        pd.DataFrame(columns=["date", "district", "rainfall_mm"]).to_csv(OUT_PATH, index=False)
        return
    df = standardize(df)
    df.to_csv(OUT_PATH, index=False)
    print(f"Saved {len(df)} rows to {OUT_PATH}")


if __name__ == "__main__":
    main()
