"""
02_fetch_river_gauge.py
------------------------
Loads daily river gauge level data for stations near coastal Odisha districts
(e.g. Mahanadi, Brahmani, Baitarani river basins).

CWC / India-WRIS does not have a clean open API for bulk historical download;
the practical approach is:
  1. Manually download station-wise CSVs from ffs.india-water.gov.in (Flood
     Forecasting) or India-WRIS portal for your chosen stations, place them in
     data/raw/river_gauge/.
  2. This script standardizes & maps each station to its district, then
     aggregates to daily district-level gauge level + flood-stage flag.

Output: data/processed/river_gauge_daily.csv
Columns: date, district, gauge_level_m, flood_stage_m, gauge_above_flood_stage
"""

import os
import pandas as pd

RAW_DIR = "data/raw/river_gauge"
OUT_PATH = "data/processed/river_gauge_daily.csv"

# Map gauge station name -> district + its danger/flood stage level (meters)
# Fill in real station names & flood-stage values from CWC bulletins.
STATION_DISTRICT_MAP = {
    "Mundali": {"district": "Cuttack", "flood_stage_m": 13.0},     # Mahanadi - reference, may not be in coastal set
    "Jenapur": {"district": "Jajpur", "flood_stage_m": 16.0},       # Brahmani - example
    "Anandapur": {"district": "Kendrapara", "flood_stage_m": 12.0},  # placeholder - verify
    # Add more stations relevant to Puri, Ganjam, Balasore, Bhadrak, Jagatsinghpur
}


def load_manual_csvs():
    frames = []
    if not os.path.isdir(RAW_DIR):
        return None
    for fname in os.listdir(RAW_DIR):
        if fname.lower().endswith(".csv"):
            df = pd.read_csv(os.path.join(RAW_DIR, fname))
            station = os.path.splitext(fname)[0]
            df["station"] = station
            frames.append(df)
    if not frames:
        return None
    return pd.concat(frames, ignore_index=True)


def standardize(df):
    col_map = {
        "Date": "date",
        "DATE": "date",
        "Level": "gauge_level_m",
        "Water Level": "gauge_level_m",
        "GaugeLevel": "gauge_level_m",
    }
    df = df.rename(columns=col_map)
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df["gauge_level_m"] = pd.to_numeric(df["gauge_level_m"], errors="coerce")

    df["district"] = df["station"].map(lambda s: STATION_DISTRICT_MAP.get(s, {}).get("district"))
    df["flood_stage_m"] = df["station"].map(lambda s: STATION_DISTRICT_MAP.get(s, {}).get("flood_stage_m"))
    df = df.dropna(subset=["date", "district", "gauge_level_m"])
    df["gauge_above_flood_stage"] = (df["gauge_level_m"] >= df["flood_stage_m"]).astype(int)

    # If multiple stations map to same district, average per day
    daily = (
        df.groupby(["date", "district"])
        .agg(gauge_level_m=("gauge_level_m", "mean"),
             flood_stage_m=("flood_stage_m", "first"),
             gauge_above_flood_stage=("gauge_above_flood_stage", "max"))
        .reset_index()
    )
    return daily


def main():
    os.makedirs("data/processed", exist_ok=True)
    df = load_manual_csvs()
    if df is None:
        print(f"No river gauge CSVs found in {RAW_DIR}/. "
              f"Download from ffs.india-water.gov.in and place them there.")
        pd.DataFrame(columns=["date", "district", "gauge_level_m",
                               "flood_stage_m", "gauge_above_flood_stage"]).to_csv(OUT_PATH, index=False)
        return
    df = standardize(df)
    df.to_csv(OUT_PATH, index=False)
    print(f"Saved {len(df)} rows to {OUT_PATH}")


if __name__ == "__main__":
    main()
