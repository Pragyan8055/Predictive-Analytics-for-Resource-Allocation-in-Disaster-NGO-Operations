"""
03_fetch_incidents.py
-----------------------
Builds the disaster-incident table and the TARGET variable (resource demand).

Real dispatch data (kits/water/ORS distributed per district per week) is rarely
available as clean CSV. Two tracks:

TRACK A — Real incident records:
  Manually compile from OSDMA situation reports / ReliefWeb / NDMA archives into
  data/raw/incidents/incidents.csv with columns:
    date, district, event_type (flood/cyclone/heatwave), affected_population,
    severity (1-5), kits_distributed, water_liters_distributed, ors_units_distributed
  (fill whichever target columns you can find; leave blanks if unknown)

TRACK B — Synthetic target (fallback, always runs):
  For weeks with a recorded incident but no dispatch numbers, estimate demand using
  SPHERE Handbook per-capita norms:
    - water: 15 L/person/day
    - food (dry ration): 2.1 kg/person/day -> converted to "kits" (1 kit = 1 family/5 ppl/week)
    - ORS: 1 unit per person per flood-week (rough heuristic, adjust as needed)

Output: data/processed/incidents_weekly.csv
Columns: week_start_date, district, incident_count, severity_avg,
         target_kits_demand, target_water_liters_demand, target_ors_units_demand,
         is_synthetic_target
"""

import os
import pandas as pd

RAW_PATH = "data/raw/incidents/incidents.csv"
OUT_PATH = "data/processed/incidents_weekly.csv"

# SPHERE-derived per-capita norms (rough, adjust with real SPHERE handbook values)
WATER_LITERS_PER_PERSON_PER_DAY = 15
RATION_KG_PER_PERSON_PER_DAY = 2.1
KIT_COVERS_PEOPLE = 5          # 1 family kit ~ 5 people
ORS_UNITS_PER_PERSON_PER_EVENT = 1


def load_raw():
    if not os.path.exists(RAW_PATH):
        return None
    return pd.read_csv(RAW_PATH)


def main():
    os.makedirs("data/processed", exist_ok=True)
    df = load_raw()
    if df is None:
        print(f"No incident file found at {RAW_PATH}. "
              f"Create it manually from OSDMA/NDMA situation reports / ReliefWeb.")
        pd.DataFrame(columns=[
            "week_start_date", "district", "incident_count", "severity_avg",
            "target_kits_demand", "target_water_liters_demand",
            "target_ors_units_demand", "is_synthetic_target"
        ]).to_csv(OUT_PATH, index=False)
        return

    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df["week_start_date"] = df["date"] - pd.to_timedelta(df["date"].dt.weekday, unit="D")
    df["district"] = df["district"].str.strip().str.title()

    # Synthetic targets where dispatch numbers missing
    df["is_synthetic_target"] = df[["kits_distributed", "water_liters_distributed",
                                     "ors_units_distributed"]].isna().any(axis=1).astype(int)

    pop = df["affected_population"].fillna(0)
    days_assumed = 7  # assume 1 week of relief need per incident

    df["target_water_liters_demand"] = df["water_liters_distributed"].fillna(
        pop * WATER_LITERS_PER_PERSON_PER_DAY * days_assumed
    )
    df["target_kits_demand"] = df["kits_distributed"].fillna(
        (pop / KIT_COVERS_PEOPLE).round()
    )
    df["target_ors_units_demand"] = df["ors_units_distributed"].fillna(
        pop * ORS_UNITS_PER_PERSON_PER_EVENT
    )

    weekly = (
        df.groupby(["week_start_date", "district"])
        .agg(
            incident_count=("event_type", "count"),
            severity_avg=("severity", "mean"),
            target_kits_demand=("target_kits_demand", "sum"),
            target_water_liters_demand=("target_water_liters_demand", "sum"),
            target_ors_units_demand=("target_ors_units_demand", "sum"),
            is_synthetic_target=("is_synthetic_target", "max"),
        )
        .reset_index()
    )
    weekly.to_csv(OUT_PATH, index=False)
    print(f"Saved {len(weekly)} rows to {OUT_PATH}")


if __name__ == "__main__":
    main()
