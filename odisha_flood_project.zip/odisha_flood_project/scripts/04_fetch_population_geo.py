"""
04_fetch_population_geo.py
----------------------------
Loads district population/density and district boundary geometries.

1. Population: Census 2011 district-wise population (static table you download
   once from censusindia.gov.in or data.gov.in and place at
   data/raw/population/odisha_population.csv with columns: district, population, area_sqkm)

2. Boundaries: District shapefile/GeoJSON for Odisha. Download from:
   - data.gov.in ("Odisha district boundary shapefile")
   - GADM (gadm.org -> India -> level 2 districts) -> filter to Odisha
   Place the file at data/geo/odisha_districts.geojson (or .shp)

Output:
  data/processed/population_density.csv  (district, population, area_sqkm, population_density)
  data/geo/odisha_districts.geojson       (filtered to coastal districts, used by dashboard
                                            and for road-density zonal stats)
"""

import os
import pandas as pd

try:
    import geopandas as gpd
except ImportError:
    gpd = None

POP_RAW = "data/raw/population/odisha_population.csv"
POP_OUT = "data/processed/population_density.csv"

GEO_RAW_CANDIDATES = [
    "data/geo/odisha_districts_raw.geojson",
    "data/geo/odisha_districts_raw.shp",
]
GEO_OUT = "data/geo/odisha_districts.geojson"

COASTAL_DISTRICTS = ["Puri", "Ganjam", "Kendrapara", "Balasore", "Bhadrak", "Jagatsinghpur"]


def process_population():
    if not os.path.exists(POP_RAW):
        print(f"No population file at {POP_RAW}. "
              f"Download Census 2011 district table and place it there "
              f"(columns: district, population, area_sqkm).")
        pd.DataFrame(columns=["district", "population", "area_sqkm",
                               "population_density"]).to_csv(POP_OUT, index=False)
        return
    df = pd.read_csv(POP_RAW)
    df["district"] = df["district"].str.strip().str.title()
    df = df[df["district"].isin(COASTAL_DISTRICTS)]
    df["population_density"] = df["population"] / df["area_sqkm"]
    os.makedirs("data/processed", exist_ok=True)
    df.to_csv(POP_OUT, index=False)
    print(f"Saved population data for {len(df)} districts to {POP_OUT}")


def process_geo():
    if gpd is None:
        print("geopandas not installed — skipping boundary processing.")
        return
    src = next((p for p in GEO_RAW_CANDIDATES if os.path.exists(p)), None)
    if src is None:
        print(f"No district boundary file found. Place a shapefile/GeoJSON at one of: "
              f"{GEO_RAW_CANDIDATES}")
        return
    gdf = gpd.read_file(src)
    # Try to find district name column
    name_col = next((c for c in gdf.columns if "dist" in c.lower() or "name" in c.lower()), None)
    if name_col is None:
        raise ValueError("Could not auto-detect district name column; inspect columns manually.")
    gdf[name_col] = gdf[name_col].str.strip().str.title()
    gdf = gdf[gdf[name_col].isin(COASTAL_DISTRICTS)]
    gdf = gdf.rename(columns={name_col: "district"})
    os.makedirs("data/geo", exist_ok=True)
    gdf.to_file(GEO_OUT, driver="GeoJSON")
    print(f"Saved {len(gdf)} district geometries to {GEO_OUT}")


if __name__ == "__main__":
    process_population()
    process_geo()
