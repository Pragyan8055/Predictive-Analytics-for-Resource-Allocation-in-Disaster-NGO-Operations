"""
05_fetch_roads_osm.py
-----------------------
Computes road-network density (km of road per sq km) for each coastal Odisha
district using OpenStreetMap data via OSMnx. Fully automatic — no manual
download needed (requires internet access).

Output: data/processed/road_density.csv
Columns: district, road_length_km, area_sqkm, road_density_km_per_sqkm
"""

import os
import pandas as pd

try:
    import osmnx as ox
    import geopandas as gpd
except ImportError:
    ox = None
    gpd = None

OUT_PATH = "data/processed/road_density.csv"
COASTAL_DISTRICTS = ["Puri", "Ganjam", "Kendrapara", "Balasore", "Bhadrak", "Jagatsinghpur"]


def main():
    os.makedirs("data/processed", exist_ok=True)
    if ox is None:
        print("osmnx/geopandas not installed. Install with: "
              "pip install osmnx geopandas --break-system-packages")
        pd.DataFrame(columns=["district", "road_length_km", "area_sqkm",
                               "road_density_km_per_sqkm"]).to_csv(OUT_PATH, index=False)
        return

    rows = []
    for district in COASTAL_DISTRICTS:
        place = f"{district} District, Odisha, India"
        try:
            print(f"Fetching road network for {place} ...")
            G = ox.graph_from_place(place, network_type="drive")
            gdf_edges = ox.graph_to_gdfs(G, nodes=False)
            road_length_km = gdf_edges["length"].sum() / 1000.0

            gdf_boundary = ox.geocode_to_gdf(place)
            area_sqkm = gdf_boundary.to_crs(epsg=3857).area.iloc[0] / 1e6

            rows.append({
                "district": district,
                "road_length_km": road_length_km,
                "area_sqkm": area_sqkm,
                "road_density_km_per_sqkm": road_length_km / area_sqkm,
            })
        except Exception as e:
            print(f"Failed for {district}: {e}")
            rows.append({"district": district, "road_length_km": None,
                          "area_sqkm": None, "road_density_km_per_sqkm": None})

    pd.DataFrame(rows).to_csv(OUT_PATH, index=False)
    print(f"Saved {len(rows)} rows to {OUT_PATH}")


if __name__ == "__main__":
    main()
