"""
06_feature_engineering.py
---------------------------
Builds engineered features from rainfall_daily.csv and river_gauge_daily.csv:

1. Resample to weekly per district.
2. HAR-style lag aggregates (daily / weekly / monthly rolling means) — the
   classic HAR-RV idea applied to rainfall/gauge series instead of volatility.
3. Wavelet decomposition (PyWavelets, 'db4', level=3) of the weekly rainfall
   series per district -> approximation + detail coefficient columns.
4. Standard autoregressive lag features (t-1, t-2, t-4) of rainfall and gauge.

Output: data/processed/features_weekly.csv
Columns: week_start_date, district, rainfall_mm_sum,
         rainfall_har_daily, rainfall_har_weekly, rainfall_har_monthly,
         rainfall_lag1, rainfall_lag2, rainfall_lag4,
         gauge_level_mean, gauge_above_flood_stage_any,
         wavelet_approx, wavelet_detail_1, wavelet_detail_2, wavelet_detail_3
"""

import os
import numpy as np
import pandas as pd

try:
    import pywt
except ImportError:
    pywt = None

RAIN_PATH = "data/processed/rainfall_daily.csv"
GAUGE_PATH = "data/processed/river_gauge_daily.csv"
OUT_PATH = "data/processed/features_weekly.csv"

WAVELET = "db4"
WAVELET_LEVEL = 3


def weekly_resample_rainfall(rain):
    rain["week_start_date"] = rain["date"] - pd.to_timedelta(rain["date"].dt.weekday, unit="D")
    weekly = (
        rain.groupby(["district", "week_start_date"])["rainfall_mm"]
        .sum()
        .reset_index()
        .rename(columns={"rainfall_mm": "rainfall_mm_sum"})
    )
    return weekly


def add_har_features(df):
    """HAR-style multi-horizon rolling means per district, computed on weekly series."""
    df = df.sort_values(["district", "week_start_date"])
    out = []
    for district, g in df.groupby("district"):
        g = g.copy()
        g["rainfall_har_daily"] = g["rainfall_mm_sum"].shift(1)                       # last week (proxy "daily/short")
        g["rainfall_har_weekly"] = g["rainfall_mm_sum"].shift(1).rolling(4).mean()    # ~monthly avg of weekly sums
        g["rainfall_har_monthly"] = g["rainfall_mm_sum"].shift(1).rolling(12).mean()  # ~quarterly avg
        g["rainfall_lag1"] = g["rainfall_mm_sum"].shift(1)
        g["rainfall_lag2"] = g["rainfall_mm_sum"].shift(2)
        g["rainfall_lag4"] = g["rainfall_mm_sum"].shift(4)
        out.append(g)
    return pd.concat(out, ignore_index=True)


def add_wavelet_features(df):
    """Per-district wavelet decomposition of the weekly rainfall series."""
    if pywt is None:
        print("PyWavelets not installed (pip install PyWavelets). Skipping wavelet features.")
        for col in ["wavelet_approx", "wavelet_detail_1", "wavelet_detail_2", "wavelet_detail_3"]:
            df[col] = np.nan
        return df

    out = []
    for district, g in df.groupby("district"):
        g = g.sort_values("week_start_date").copy()
        series = g["rainfall_mm_sum"].fillna(0).values
        if len(series) < 2 ** WAVELET_LEVEL:
            for col in ["wavelet_approx", "wavelet_detail_1", "wavelet_detail_2", "wavelet_detail_3"]:
                g[col] = np.nan
            out.append(g)
            continue

        coeffs = pywt.wavedec(series, WAVELET, level=WAVELET_LEVEL, mode="periodization")
        # coeffs = [cA_n, cD_n, ..., cD_1]
        # Reconstruct each component back to original length for alignment
        def reconstruct(idx):
            zeroed = [c if i == idx else np.zeros_like(c) for i, c in enumerate(coeffs)]
            rec = pywt.waverec(zeroed, WAVELET, mode="periodization")
            return rec[:len(series)]

        g["wavelet_approx"] = reconstruct(0)
        for i in range(1, WAVELET_LEVEL + 1):
            g[f"wavelet_detail_{WAVELET_LEVEL + 1 - i}"] = reconstruct(i)
        out.append(g)
    return pd.concat(out, ignore_index=True)


def add_gauge_features(features, gauge):
    gauge["week_start_date"] = gauge["date"] - pd.to_timedelta(gauge["date"].dt.weekday, unit="D")
    gauge_weekly = (
        gauge.groupby(["district", "week_start_date"])
        .agg(gauge_level_mean=("gauge_level_m", "mean"),
             gauge_above_flood_stage_any=("gauge_above_flood_stage", "max"))
        .reset_index()
    )
    return features.merge(gauge_weekly, on=["district", "week_start_date"], how="left")


def main():
    os.makedirs("data/processed", exist_ok=True)

    if not os.path.exists(RAIN_PATH):
        print(f"{RAIN_PATH} not found — run 01_fetch_rainfall.py first.")
        pd.DataFrame().to_csv(OUT_PATH, index=False)
        return

    rain = pd.read_csv(RAIN_PATH, parse_dates=["date"])
    if rain.empty:
        print("rainfall_daily.csv is empty — populate raw data first.")
        pd.DataFrame().to_csv(OUT_PATH, index=False)
        return

    weekly = weekly_resample_rainfall(rain)
    weekly = add_har_features(weekly)
    weekly = add_wavelet_features(weekly)

    if os.path.exists(GAUGE_PATH):
        gauge = pd.read_csv(GAUGE_PATH, parse_dates=["date"])
        if not gauge.empty:
            weekly = add_gauge_features(weekly, gauge)

    weekly.to_csv(OUT_PATH, index=False)
    print(f"Saved {len(weekly)} rows to {OUT_PATH}")


if __name__ == "__main__":
    main()
