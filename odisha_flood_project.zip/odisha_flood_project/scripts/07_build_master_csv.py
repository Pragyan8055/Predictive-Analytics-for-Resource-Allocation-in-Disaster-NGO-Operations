"""
07_build_master_csv.py
------------------------
Merges all processed tables into a single master_csv at (district, week) grain,
ready for SARIMA / HAR / wavelet-augmented LightGBM/LSTM modeling.

Inputs (all from data/processed/, produced by scripts 01-06):
  - features_weekly.csv        (rainfall, HAR lags, wavelet, gauge)
  - incidents_weekly.csv        (incident counts + target demand columns)
  - population_density.csv      (static, district-level)
  - road_density.csv            (static, district-level)

Output: data/processed/master_csv.csv
"""

import os
import pandas as pd

PROC_DIR = "data/processed"
OUT_PATH = os.path.join(PROC_DIR, "master_csv.csv")


def safe_read(path, parse_dates=None):
    if os.path.exists(path):
        df = pd.read_csv(path, parse_dates=parse_dates)
        if not df.empty:
            return df
    print(f"Warning: {path} missing or empty.")
    return None


def main():
    features = safe_read(os.path.join(PROC_DIR, "features_weekly.csv"),
                          parse_dates=["week_start_date"])
    incidents = safe_read(os.path.join(PROC_DIR, "incidents_weekly.csv"),
                           parse_dates=["week_start_date"])
    population = safe_read(os.path.join(PROC_DIR, "population_density.csv"))
    roads = safe_read(os.path.join(PROC_DIR, "road_density.csv"))

    if features is None:
        print("features_weekly.csv is required and missing/empty. "
              "Run scripts 01 and 06 first. Aborting.")
        return

    master = features.copy()

    # Merge incident/target data (time-varying)
    if incidents is not None:
        master = master.merge(incidents, on=["district", "week_start_date"], how="left")
        target_cols = ["incident_count", "severity_avg", "target_kits_demand",
                        "target_water_liters_demand", "target_ors_units_demand",
                        "is_synthetic_target"]
        for col in target_cols:
            if col in master.columns:
                master[col] = master[col].fillna(0)
    else:
        for col in ["target_kits_demand", "target_water_liters_demand",
                     "target_ors_units_demand"]:
            master[col] = pd.NA

    # Merge static district-level features
    if population is not None:
        master = master.merge(population, on="district", how="left")
    if roads is not None:
        master = master.merge(roads, on="district", how="left")

    # Past-incident rolling features (4-week trailing count)
    if "incident_count" in master.columns:
        master = master.sort_values(["district", "week_start_date"])
        master["past_incident_count_4wk"] = (
            master.groupby("district")["incident_count"]
            .transform(lambda s: s.shift(1).rolling(4, min_periods=1).sum())
        )

    os.makedirs(PROC_DIR, exist_ok=True)
    master.to_csv(OUT_PATH, index=False)
    print(f"Saved master_csv with {len(master)} rows and {len(master.columns)} columns "
          f"to {OUT_PATH}")
    print("Columns:", list(master.columns))


if __name__ == "__main__":
    main()
